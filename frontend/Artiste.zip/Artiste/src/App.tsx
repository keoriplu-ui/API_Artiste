import './App.css'
import { useEffect, useState } from 'react'
import type { Artist } from './types.ts'
import type { Concert } from './types.ts'

const API_URL = 'http://localhost:3500'

function App() {
  const [artists, setArtists] = useState<Artist[]>([])
  const [concerts, setConcerts] = useState<Concert[]>([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)

  useEffect(() => {
    async function loadData() {
      try {
        const [artistsRes, concertsRes] = await Promise.all([
          fetch(`${API_URL}/artists`),
          fetch(`${API_URL}/concerts`),
        ])

        if (!artistsRes.ok || !concertsRes.ok) {
          throw new Error('Erreur lors de la récupération des données')
        }

        const artistsData: Artist[] = await artistsRes.json()
        const concertsData: Concert[] = await concertsRes.json()

        setArtists(artistsData)
        setConcerts(concertsData)
      } catch (err) {
        setError(err instanceof Error ? err.message : 'Erreur inconnue')
      } finally {
        setLoading(false)
      }
    }

    loadData()
  }, [])

  if (loading) return <p>Chargement...</p>
  if (error) return <p>Erreur : {error}</p>

  return (
    <div>
      <h1>Artistes</h1>
      <ul>
        {artists.map((artist) => (
          <li key={artist.id}>
            {artist.name} ({artist.genre})
          </li>
        ))}
      </ul>

      <h1>Concerts</h1>
      <ul>
        {concerts.map((concert) => {
          const artist = artists.find((a) => a.id === concert.ArtistId)
          return (
            <li key={concert.id}>
              {new Date(concert.date).toLocaleDateString('fr-FR')} -{' '}
              {artist?.name ?? 'Artiste inconnu'}
            </li>
          )
        })}
      </ul>
    </div>
  )
}

export default App
