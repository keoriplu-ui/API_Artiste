export interface Artist {
    id: number;
    name: string;
    genre: string;
}

export interface Concert {
    id: number;
    date: string;
    ArtistId: number;
}